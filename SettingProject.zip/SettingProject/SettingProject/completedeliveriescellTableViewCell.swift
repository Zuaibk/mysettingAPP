//
//  completedeliveriescellTableViewCell.swift
//  SettingProject
//
//  Created by mac on 14/02/2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class completedeliveriescellTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

//
//  ViewController.swift
//  SettingProject
//
//  Created by mac on 12/02/2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var orderlabel: UILabel!
    
    @IBOutlet weak var orderIn: UILabel!
    
    @IBOutlet weak var Mytableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
   //private func setTableView(){
    
    //let nibCell = UINib(nibName: "Viewcontroller", bundle: nil)
        
      //  self.Mytableview.register(nibCell, forCellReuseIdentifier: "")
        
        
    //}
    
}

